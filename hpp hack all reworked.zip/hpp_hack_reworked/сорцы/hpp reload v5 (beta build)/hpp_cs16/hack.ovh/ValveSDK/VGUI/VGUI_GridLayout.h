//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#ifndef VGUI_GRIDLAYOUT_H
#define VGUI_GRIDLAYOUT_H

#include "VGUI.h"
#include "VGUI_Layout.h"

namespace vgui
{

/*
class VGUIAPI GridLayout : public Layout
{
public:
	GridLayout(int rows,int cols,int hgap,int vgap);
protected:
	int _rows;
	int _cols;
};
*/

}

#endif