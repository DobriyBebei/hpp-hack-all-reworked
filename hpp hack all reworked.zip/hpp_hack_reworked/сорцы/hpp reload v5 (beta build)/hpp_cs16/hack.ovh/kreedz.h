class CKreedz;
class CKreedz {
private:
	void RageBunnyHop(usercmd_s* cmd);
public:
	void Run(usercmd_s* cmd);
};

extern CKreedz g_Kreedz;